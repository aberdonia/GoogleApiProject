# GoogleApiProject

The contects of this project are in the index_ko.html file. This includes css, js and html.

You will also need knockout.js ads found in the repository.

Simply clone and then launch index_ko.html in your browser.

Thanks!
